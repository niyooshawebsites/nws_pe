<?php require_once __DIR__ . '/../config/config.php'; ?>
<?php global $config; ?>

<?php
$license_key = $config['LICENSE_KEY']; // Your license key
$product_id = 1885; // Your renewal product ID

$renew_url = "https://niyooshawebsitesllp.in/renew-license/?add-to-cart=$product_id&license_key=" . urlencode($license_key);

// Create date objects
$today = new DateTime();
$expiryDate = new DateTime($config['LICENSE_EXPIRY']);

// Calculate difference
$interval = $today->diff($expiryDate);
$daysRemaining = (int)$interval->format('%r%a'); // signed integer
?>


<nav class="navbar navbar-expand-lg bg-body-tertiary border-bottom">
    <div class="container-fluid">
        <!-- Brand -->
        <a class="navbar-brand" href="/index.php"><?php echo $config['APP_NAME']; ?></a>

        <!-- Toggler -->
        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar"
            aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Offcanvas Menu -->
        <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar"
            aria-labelledby="offcanvasNavbarLabel">
            <div class="offcanvas-header">
                <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Menu</h5>
                <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas"
                    aria-label="Close"></button>
            </div>

            <div class="offcanvas-body">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <?php if (isset($_SESSION['user'])): ?>
                        <li class="nav-item">
                            <a class="nav-link text-primary" href="#">
                                <?php if ($_SESSION['user']['role'] === 'admin'): ?>
                                    Welcome <span class="text-primary">ADMIN</span>,
                                <?php else: ?>
                                    Welcome <span class="text-primary"><?= htmlspecialchars($_SESSION['user']['name']); ?></span>,
                                <?php endif; ?>
                            </a>
                        </li>
                        <?php if ($_SESSION['user']['role'] === 'user'): ?>
                            <li class="nav-item">
                                <a class="btn btn-primary" href="/user/dashboard.php">New Request</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-danger fw-bold blink-success" href="/user/all_listed_properties.php">ON SALE</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-success fw-bold blink-success" href="/user/all_rented_properties.php">ON RENT</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#loanCalculatorModal">
                                    Loan Calculator
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="/user/my_entries.php">My Requests</a>
                            </li>
                        <?php endif; ?>

                        <?php if ($_SESSION['user']['role'] === 'admin'): ?>
                            <!--<li class="nav-item mx-2">-->
                            <!--    <span href="<?= $renew_url ?>" class="btn btn-danger" target="_blank">Your license expires in <?= $daysRemaining ?> days</span>-->
                            <!--</li>-->
                            <!--<li class="nav-item">-->
                            <!--    <a href="<?= $renew_url ?>" class="btn btn-warning" target="_blank">Renew License</a>-->
                            <!--</li>-->
                            <li class="nav-item">
                                <a class="nav-link" href="/admin/dashboard.php">My Dashboard</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="/admin/locations.php">Locations</a>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    Requests
                                </a>
                                <ul class="dropdown-menu bg-dark">
                                    <li>
                                        <a class="dropdown-item text-primary" href="buy_data.php">Buy Requests</a>
                                    </li>
                                    <li>
                                        <hr class="dropdown-divider">
                                    </li>
                                    <li>
                                        <a class="dropdown-item text-danger" href="sell_data.php">Sell Requests</a>
                                    </li>
                                    <li>
                                        <hr class="dropdown-divider">
                                    </li>
                                    <li>
                                        <a class="dropdown-item text-warning" href="landLord_data.php">Landlord Requests</a>
                                    </li>
                                    <li>
                                        <hr class="dropdown-divider">
                                    </li>
                                    <li>
                                        <a class="dropdown-item text-success" href="tenant_data.php">Tenant Requests</a>
                                    </li>
                                </ul>
                            </li>
                        <?php endif; ?>

                        <li class="nav-item">
                            <a class="nav-link" href="/profile.php">Profile</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/logout.php">logout</a>
                        </li>

                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="mailto:<?php echo $config['ADMIN_EMAIL']; ?>"><i class="bi bi-envelope"></i></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-" href="tel:<?php echo $config['ADMIN_MOBILE']; ?>"><i class="bi bi-telephone"></i></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-danger" href="/properties_available_for_sale.php">On SALE</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-success" href="/properties_available_for_rent.php">On RENT</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#loanCalculatorModal">
                                Loan Calculator
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/login.php">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/register.php">Register</a>
                        </li>
                        <li class="nav-item">
                            <a class="btn btn-success" id="installApp">APP <i class="bi bi-cloud-arrow-down-fill" style="font-size: 18px"></i> </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</nav>

<?php include 'translate_widget.php'; ?>