<?php
session_start();

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $license_key = trim($_POST['license_key']);
    $domain = parse_url("http://" . $_SERVER['HTTP_HOST'], PHP_URL_HOST); // sanitize domain

    // WooCommerce REST API credentials
    $consumer_key = 'ck_b51921f77c3876895b5a72f4e11a10918a168ec1';
    $consumer_secret = 'cs_fdda832853ff1c57c869ceb75f7942fcdd792dc7';

    // Correct activation endpoint
    $activate_url = "https://niyooshawebsitesllp.in/wp-json/lmfwc/v2/licenses/activate/" . urlencode($license_key);

    // Initialize cURL
    $ch = curl_init($activate_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

    // Authentication header
    $auth = base64_encode("$consumer_key:$consumer_secret");
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Basic $auth",
        "Content-Type: application/json"
    ]);

    $response = curl_exec($ch);

    if ($response === false) {
        $error = '❌ cURL Error: ' . curl_error($ch);
        curl_close($ch);
    } else {
        $http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $data = json_decode($response, true);

        if (
            $http_status === 200 &&
            isset($data['success']) && $data['success'] === true &&
            isset($data['data']['licenseKey']) &&
            $data['data']['licenseKey'] === $license_key
        ) {
            $_SESSION['license_key'] = $license_key;

            // Calculate expiry date (365 days from now)
            $expiry_date = (new DateTime())->add(new DateInterval('P365D'))->format('Y-m-d');
            $_SESSION['license_expiry'] = $expiry_date;

            file_put_contents(__DIR__ . "/verified.flag", "verified");

            $success = "✅ License activated successfully. Redirecting...";

            echo "<script>setTimeout(function(){ window.location.href='index.php'; }, 2000);</script>";
        } else {
            // Show custom message for invalid license
            if (isset($data['message']) && str_contains(strtolower($data['message']), 'could not be found')) {
                $error = "❌ Invalid license key! Please check and enter a valid license key.";
            } else {
                $error = $data['message'] ?? "❌ License activation failed!";
            }
        }
    }
}
?>

<?php
$pageTitle = "License Verification";
include '../comps/header.php';
?>

<body class="container mt-5">
    <div class="card shadow-lg">
        <div class="card-body">
            <h3 class=" text-center lead">Welcome to</h3>
            <h1 class="mb-4 display-2 text-primary text-center">PROPERTY EXPERT</h1>
            <hr />
            <p class=" text-center lead">Take your property business to the next level</p>
            <h2 class="text-center text-primary mb-4">License Verification</h2>

            <?php if ($success): ?>
                <div class="alert alert-success text-center"><?= htmlspecialchars($success) ?></div>
            <?php elseif ($error): ?>
                <div class="alert alert-danger text-center"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <form method="post" class="mt-4">
                <div class="mb-3">
                    <label for="license_key" class="form-label">Enter your license key to activate the application</label>
                    <input type="text" name="license_key" id="license_key" class="form-control" placeholder="XXXX-XXXX-XXXX-XXXX" required>
                </div>
                <button type="submit" class="btn btn-primary w-100">Verify & Activate</button>
            </form>
        </div>
    </div>

    <?php include '/comps/footer.php' ?>
</body>

</html>