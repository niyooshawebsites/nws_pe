<?php
session_start();

if (!file_exists(__DIR__ . "/verified.flag")) {
    header("Location: verify.php");
    exit;
}

$step = isset($_GET['step']) ? (int)$_GET['step'] : 1;

function getFormData($key)
{
    return $_POST[$key] ?? '';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($step === 2) {
        $_SESSION['app_name'] = getFormData('app_name');
        $_SESSION['db_host'] = "localhost";
        $_SESSION['db_name'] = getFormData('db_name');
        $_SESSION['db_user'] = getFormData('db_user');
        $_SESSION['db_pass'] = getFormData('db_pass');
        $_SESSION['admin_email'] = getFormData('email');
        $_SESSION['admin_mobile'] = getFormData('mobile');
        $_SESSION['business_Address'] = getFormData('businessAddress');

        $adminName = getFormData('name');
        $adminEmail = getFormData('email');
        $adminMobile = getFormData('mobile');
        $adminPasswordRaw = getFormData('password');
        $adminPasswordHashed = password_hash($adminPasswordRaw, PASSWORD_BCRYPT);

        $tempConn = @new mysqli($_SESSION['db_host'], $_SESSION['db_user'], $_SESSION['db_pass']);
        if ($tempConn->connect_error) {
            $error = "Database connection failed: " . $tempConn->connect_error;
        } else {
            $dbName = $tempConn->real_escape_string($_SESSION['db_name']);
            $createDbSql = "CREATE DATABASE IF NOT EXISTS $dbName CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci";
            if (!$tempConn->query($createDbSql)) {
                $error = "Database creation failed: " . $tempConn->error;
            } else {
                $conn = new mysqli($_SESSION['db_host'], $_SESSION['db_user'], $_SESSION['db_pass'], $dbName);
                if ($conn->connect_error) {
                    $error = "Database connection failed after creation: " . $conn->connect_error;
                } else {
                    $schemaPath = __DIR__ . '/../sql/schema.sql';
                    if (!$schemaPath || !file_exists($schemaPath)) {
                        $error = "SQL schema file not found at expected path: ../sql/schema.sql";
                    } else {
                        $sql = file_get_contents($schemaPath);
                        if ($conn->multi_query($sql)) {
                            do {
                                $conn->store_result();
                            } while ($conn->next_result());

                            // Insert default admin
                            $role = 'admin';
                            $insertAdminSQL = "INSERT INTO users (name, email, mobile, password, role) VALUES (?, ?, ?, ?, ?)";
                            $stmt = $conn->prepare($insertAdminSQL);
                            $stmt->bind_param("sssss", $adminName, $adminEmail, $adminMobile, $adminPasswordHashed, $role);
                            $stmt->execute();
                            $stmt->close();

                            // Save config
                            $configArray = [
                                'APP_NAME' => $_SESSION['app_name'],
                                'LICENSE_KEY' => $_SESSION['license_key'],
                                'LICENSE_EXPIRY' => $_SESSION['license_expiry'],
                                'DB_HOST' => $_SESSION['db_host'],
                                'DB_USER' => $_SESSION['db_user'],
                                'DB_PASS' => $_SESSION['db_pass'],
                                'DB_NAME' => $_SESSION['db_name'],
                                'ADMIN_EMAIL' => $_SESSION['admin_email'],
                                'ADMIN_MOBILE' => $_SESSION['admin_mobile'],
                                'BUSINESS_ADDRESS' => $_SESSION['business_Address']
                            ];

                            file_put_contents(__DIR__ . '/../config/config.php', "<?php\nreturn " . var_export($configArray, true) . ";\n?>");

                            // Delete setup folder
                            function deleteFolder($folderPath)
                            {
                                if (!is_dir($folderPath)) return;
                                foreach (scandir($folderPath) as $item) {
                                    if ($item === '.' || $item === '..') continue;
                                    $path = $folderPath . DIRECTORY_SEPARATOR . $item;
                                    if (is_dir($path)) {
                                        deleteFolder($path);
                                    } else {
                                        unlink($path);
                                    }
                                }
                                rmdir($folderPath);
                            }

                            $setupPath = realpath(__DIR__ . '/../setup');
                            deleteFolder($setupPath);

                            $sqlPath = realpath(__DIR__ . '/../sql');
                            deleteFolder($sqlPath);

                            // Redirect
                            header("Location: ../index.php");
                            exit;
                        } else {
                            $error = "Error running SQL script: " . $conn->error;
                        }
                    }
                }
            }
        }
    }
}

?>

<?php
$pageTitle = "Setup Wizard";
include '../comps/header.php';
?>

<body>
    <div class="container mt-5">
        <div class="card shadow-lg">
            <div class="card-body">
                <?php if ($step === 1): ?>
                    <h3 class=" text-center lead">Welcome to</h3>
                    <h1 class="mb-4 display-2 text-primary text-center">PROPERTY EXPERT</h1>
                    <p class=" text-center lead">Take your property business to the next level</p>
                    <hr class="mb-5" />
                    <h2 class="text-center text-primary mb-4">Welcome to the Setup Wizard</h2>
                    <p>This wizard will guide you through the installation process.</p>
                    <a class="btn btn-primary" href="?step=2">Start Setup</a>


                <?php elseif ($step === 2): ?>
                    <h3 class=" text-center lead">Welcome to</h3>
                    <h1 class="mb-4 display-2 text-primary text-center">PROPERTY EXPERT</h1>
                    <hr class="mb-5" />
                    <p class=" text-center lead">Take your property business to the next level</p>
                    <hr class="mb-5" />
                    <h2 class="text-center text-primary mb-4">Configuration</h2>

                    <?php if (isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>
                    <form method="post">

                        <h5>Business Details</h5>
                        <div class="mb-3">
                            <label class="form-label">Business Name</label>
                            <input type="text" name="app_name" class="form-control" placeholder="Give a name to your application" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Business Address</label>
                            <input type="text" name="businessAddress" class="form-control" placeholder="Enter your business address" required>
                        </div>
                        <hr>
                        <h5>Database Details</h5>
                        <div class="mb-3">
                            <label class="form-label">Database Name</label>
                            <input type="text" name="db_name" class="form-control" placeholder="Enter the database name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Database Username</label>
                            <input type="text" name="db_user" class="form-control" placeholder="Enter the database username" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Database Password</label>
                            <input type="password" name="db_pass" class="form-control" placeholder="Enter the database password" required>
                        </div>
                        <hr>
                        <h5>Admin Details</h5>
                        <div class="mb-3">
                            <label class="form-label">Admin Name</label>
                            <input type="text" name="name" class="form-control" placeholder="Enter your name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Admin Mobile number</label>
                            <input type="text" name="mobile" class="form-control" placeholder="Enter your mobile number" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Admin Email id</label>
                            <input type="email" name="email" class="form-control" placeholder="Enter your email id" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Admin Password</label>
                            <input type="password" name="password" class="form-control" placeholder="Enter your password" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Install</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php include '/comps/footer.php' ?>
</body>

</html>