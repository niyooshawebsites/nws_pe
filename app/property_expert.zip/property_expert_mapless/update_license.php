<?php
session_start();
$configFile = __DIR__ . '/config/config.php';

$config = require_once $configFile;
require 'includes/db.php';
require 'includes/functions.php';

if (!file_exists($configFile)) {
    $host = $_SERVER['HTTP_HOST'];
    $uri = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
    header("Location: http://$host$uri/setup/index.php");
    exit;
}

// Protect the endpoint
if ($_POST['secret'] !== 'BXiBR8wEEuG0jqWYiFMBtJe12Z99wbXHHSaoUP8zorRQPFR81A4r2bchcZz08DhR') {
    http_response_code(403);
    exit('Unauthorized');
}

// Read license key from POST
$license_key = $_POST['license_key'] ?? '';

if (!$license_key) {
    http_response_code(400);
    exit('Missing license key');
}

// Validate if license key matches
if ($config['LICENSE_KEY'] !== $license_key) {
    http_response_code(400);
    exit('Invalid license key');
}

// Extend license: 1 year from today
$new_expiry = date('Y-m-d', strtotime('+1 year'));
$config['LICENSE_EXPIRY'] = $new_expiry;

$content = "<?php\nreturn " . var_export($config, true) . ";\n";
file_put_contents($config_file, $content);

// Show alert and redirect
echo '<script>
    alert("License renewed successfully!");
    window.location.href = "/index.php";
</script>';
