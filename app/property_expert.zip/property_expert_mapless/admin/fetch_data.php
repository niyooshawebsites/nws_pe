<?php
header('Content-Type: application/json');

session_start();
$config = require_once __DIR__ . '/../config/config.php';
require '../includes/functions.php';

// Auth check
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

header('Content-Type: application/json');

$sellData = listListedPropertiesForMapping();   // Your custom function
$buyData = listPurchasePropertyForMapping();    // Your custom function

echo json_encode([
    'sellData' => $sellData,
    'buyData' => $buyData
]);
exit();
