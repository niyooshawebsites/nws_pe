-- users table
CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `email` VARCHAR(255) NOT NULL UNIQUE,
  `mobile` VARCHAR(255) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `role` ENUM('user', 'admin') NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- service localities table
CREATE TABLE `localities` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `locality` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- buyproperty table
CREATE TABLE `buyProperty` (
  `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `areaInGaj` VARCHAR(255) COLLATE utf8_unicode_ci NOT NULL,
  `locality2` VARCHAR(255) COLLATE utf8_unicode_ci NOT NULL,
  `state` VARCHAR(255) COLLATE utf8_unicode_ci NOT NULL,
  `budget` VARCHAR(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` VARCHAR(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` VARCHAR(255) COLLATE utf8_unicode_ci NOT NULL,
  `mobile` VARCHAR(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` VARCHAR(255) COLLATE utf8_unicode_ci NOT NULL,
  `typeOfProperty` ENUM('1 BHK', '2 BHK', '3 BHK', '4 BHK', 'House', 'Villa', 'Bungalow', 'Pent House', 'Shop', 'Land') COLLATE utf8_unicode_ci NOT NULL,
  `done` ENUM('no', 'yes') COLLATE utf8_unicode_ci NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `upated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- listproperty table
CREATE TABLE `listProperty` (
  `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `map_data` TEXT COLLATE utf8_unicode_ci NOT NULL,
  `currentLocation` TEXT COLLATE utf8_unicode_ci NOT NULL,
  `areaInGaj` VARCHAR(255) COLLATE utf8_unicode_ci NOT NULL,
  `typeOfProperty` ENUM('1 BHK', '2 BHK', '3 BHK', '4 BHK', 'House', 'Villa', 'Bungalow', 'Pent House', 'Shop', 'Land') COLLATE utf8_unicode_ci NOT NULL,
  `length` VARCHAR(255) COLLATE utf8_unicode_ci NOT NULL,
  `breadth` VARCHAR(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` VARCHAR(255) COLLATE utf8_unicode_ci NOT NULL,
  `locality` VARCHAR(255) COLLATE utf8_unicode_ci NOT NULL,
  `state` VARCHAR(255) COLLATE utf8_unicode_ci NOT NULL,
  `exprectedPrice` VARCHAR(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` VARCHAR(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` VARCHAR(255) COLLATE utf8_unicode_ci NOT NULL,
  `mobile` VARCHAR(255) COLLATE utf8_unicode_ci NOT NULL,
  `images` TEXT COLLATE utf8_unicode_ci DEFAULT NULL,
  `document` VARCHAR(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` VARCHAR(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` ENUM('Pending', 'Published', 'Done') COLLATE utf8_unicode_ci NOT NULL,
  `done` ENUM('no', 'yes') COLLATE utf8_unicode_ci NOT NULL,
  `interestedUsers` TEXT COLLATE utf8_unicode_ci NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `upated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- landLord table
CREATE TABLE `landLord` (
    `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT(11) NOT NULL,
    `name` VARCHAR(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
    `email` VARCHAR(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
    `mobile` VARCHAR(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
    `address` TEXT CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
    `locality2` VARCHAR(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
    `state` VARCHAR(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
    `propertyToLet` ENUM('1 BHK', '2 BHK', '3 BHK', '4 BHK', 'Studio Apartment', 'House', 'Villa', 'Bungalow', 'Pent House', 'Shop', 'Land') COLLATE utf8_unicode_ci NOT NULL,
    `floor` INT(100) NOT NULL,
    `furniture` ENUM('Furnished', 'Semi Furnished', 'Unfurnished') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
    `rent` DECIMAL(10,2) NOT NULL,
    `tenantType` ENUM('Family', 'Unmarried') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
    `food` ENUM('Veg', 'Non-veg') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
    `images` TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
    `status` ENUM('Pending', 'Published', 'Done') COLLATE utf8_unicode_ci NOT NULL,
    `interestedUsers` TEXT COLLATE utf8_unicode_ci NOT NULL,
    `done` ENUM('no', 'yes') COLLATE utf8_unicode_ci NOT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- tenant table
CREATE TABLE `tenant` (
  `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT(11) NOT NULL,
  `name` VARCHAR(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` VARCHAR(255) COLLATE utf8_unicode_ci NOT NULL,
  `mobile` VARCHAR(255) COLLATE utf8_unicode_ci NOT NULL,
  `locality2` VARCHAR(255) COLLATE utf8_unicode_ci NOT NULL,
  `state` VARCHAR(255) COLLATE utf8_unicode_ci NOT NULL,
  `typeOfProperty` ENUM('1 BHK', '2 BHK', '3 BHK', '4 BHK', 'Studio Apartment', 'House', 'Villa', 'Bungalow', 'Pent House', 'Shop', 'Land') COLLATE utf8_unicode_ci NOT NULL,
  `typeOfTenant` ENUM('Family', 'Bachelors', 'Commercial') COLLATE utf8_unicode_ci NOT NULL,
  `budget` DECIMAL(10,2) NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);