<?php
session_start();
$configFile = __DIR__ . '/config/config.php';

$config = require_once $configFile;
require 'includes/db.php';
require 'includes/functions.php';

$license_key = $config['LICENSE_KEY']; // Your license key
$product_id = 1885; // Your renewal product ID
$callback_url = urlencode("https://{$_SERVER['HTTP_HOST']}/update_license.php");
$renew_url = "https://niyooshawebsitesllp.in/checkout/?add-to-cart=$product_id&license_key=" . urlencode($license_key) . "&callback_url=$callback_url";


if (!file_exists($configFile)) {
    $host = $_SERVER['HTTP_HOST'];
    $uri = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
    header("Location: http://$host$uri/setup/index.php");
    exit;
}

?>

<?php
$pageTitle = "License Renewal";
include 'comps/header.php';
?>

<body class="bg-light d-flex flex-column justify-content-center align-items-center vh-100">

    <div class="container text-center">
        <div class="card shadow p-4">
            <p class="text-center lead">Hello</p>
            <h1 class="display-2 text-center"><?= $config['APP_NAME'] ?></h1>
            <hr />
            <h2 class="mb-3 text-danger">Your license has expired</h2>
            <p class="mb-4">Please renew your license to continue using the application.</p>
            <a class="btn btn-primary" href=<?= $renew_url ?>>Renew License</a>
        </div>
    </div>

    <?php include 'comps/footer.php' ?>
</body>

</html>