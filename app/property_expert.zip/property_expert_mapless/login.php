<?php
session_start();
$configFile = __DIR__ . '/config/config.php';

if (!file_exists($configFile)) {
    $host = $_SERVER['HTTP_HOST'];
    $uri = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
    header("Location: http://$host$uri/setup/index.php");
    exit;
}

$config = require_once $configFile;

// checking the license expiry
$expiry_date = $config['LICENSE_EXPIRY'];
$current_date = date('Y-m-d');

if ($current_date > $expiry_date) {
    header("Location: /license_renewal.php");
    exit;
}

require 'includes/db.php';
require 'includes/functions.php';

// ✅ Get the redirect parameter from query (for GET request)
$redirectAfterLogin = isset($_GET['redirect']) ? $_GET['redirect'] : '';

// Handle login submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
    $password = trim($_POST['password']);

    // ✅ Get redirect from POST form (sent via hidden input)
    $redirectAfterLogin = isset($_POST['redirect']) ? $_POST['redirect'] : '';

    if (!$email || empty($password)) {
        $error = "Please enter a valid email and password.";
    }

    $user = loginUser($email, $password);

    if ($user) {
        session_regenerate_id(true);
        $_SESSION['user'] = $user;

        // ✅ Validate redirect path (prevent external redirect)
        if (!empty($redirectAfterLogin) && strpos($redirectAfterLogin, '/') === 0 && !preg_match('/^https?:\/\//', $redirectAfterLogin)) {
            header("Location: " . $redirectAfterLogin);
        } else {
            header("Location: " . ($user['role'] === 'admin' ? 'admin/dashboard.php' : 'user/dashboard.php'));
        }
        exit();
    } else {
        $error = "Invalid email or password.";
    }
}
?>

<?php
$pageTitle = "Login";
include 'comps/header.php';
?>

<body class="app-background text-white">
    <?php include 'comps/navbar.php' ?>

    <div class="container">
        <div class="row justify-content-center align-items-center vh-100">
            <div class="col-md-6">
                <?php if (isset($_SESSION['success_msg'])): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?= $_SESSION['success_msg'] ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php unset($_SESSION['success_msg']); ?>
                <?php endif; ?>

                <?php if (isset($_SESSION['error_msg'])): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?= $_SESSION['error_msg'] ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php unset($_SESSION['error_msg']); ?>
                <?php endif; ?>

                <div class="card shadow border-primary">
                    <div class="card-header bg-primary text-white text-center">
                        <h4>Login</h4>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($error)): ?>
                            <div class="alert alert-danger"><?= $error ?></div>
                        <?php endif; ?>
                        <form method="post">
                            <!-- ✅ Hidden redirect field -->
                            <input type="hidden" name="redirect" value="<?= htmlspecialchars($redirectAfterLogin) ?>">

                            <div class="mb-3">
                                <label for="email" class="form-label">Email address</label>
                                <input type="email" class="form-control" name="email" id="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" name="password" id="password" required>
                            </div>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Login</button>
                            </div>
                        </form>
                    </div>
                    <div class="card-footer text-center">
                        <small>Don't have an account? <a href="register.php">Register here</a></small>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'comps/loan_calculator.php' ?>
    <?php include 'comps/footer.php' ?>
</body>

</html>