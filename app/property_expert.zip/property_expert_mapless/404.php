<?php
session_start();
$configFile = __DIR__ . '/config/config.php';

if (!file_exists($configFile)) {
    $host = $_SERVER['HTTP_HOST'];
    $uri = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
    header("Location: http://$host$uri/setup/index.php");
    exit;
}

$config = require_once $configFile;

// checking the license expiry
$expiry_date = $config['LICENSE_EXPIRY'];
$current_date = date('Y-m-d');

if ($current_date > $expiry_date) {
    header("Location: /license_renewal.php");
    exit;
}
?>

<?php
$pageTitle = "404";
include 'comps/header.php';
?>

<body class="app-background">
    <?php include 'comps/navbar.php' ?>
    <div class="container">
        <div class="row justify-content-center align-items-center vh-100">
            <div class="col-md-6">
                <div class="card shadow border-primary">
                    <div class="card-body text-center">
                        <h1 class="display-1 text-danger">404</h1>
                        <h2 class="display-3">Page not found!</h2>
                        <a href="/index.php" class="btn btn-primary mt-3">Back to home</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'comps/loan_calculator.php' ?>
    <?php include 'comps/footer.php' ?>
</body>

</html>