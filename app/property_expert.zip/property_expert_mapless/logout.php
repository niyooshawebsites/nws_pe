<?php
session_start();
$configFile = __DIR__ . '/config/config.php';

if (!file_exists($configFile)) {
    $host = $_SERVER['HTTP_HOST'];
    $uri = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
    header("Location: http://$host$uri/setup/index.php");
    exit;
}

$config = require_once $configFile;

// checking the license expiry
$expiry_date = $config['LICENSE_EXPIRY'];
$current_date = date('Y-m-d');

if ($current_date > $expiry_date) {
    header("Location: /license_renewal.php");
    exit;
}

// Unset all session variables
$_SESSION = array();

session_destroy();
header("Location: ../index.php");
exit();
